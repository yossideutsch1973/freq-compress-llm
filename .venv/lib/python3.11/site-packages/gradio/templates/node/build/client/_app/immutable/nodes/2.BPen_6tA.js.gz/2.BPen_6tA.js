import{Z as e,_ as n}from"../chunks/2.BnXZFkJe.js";export{e as component,n as universal};
//# sourceMappingURL=2.BPen_6tA.js.map
