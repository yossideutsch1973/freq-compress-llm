import{P as c,a as r}from"./mermaid-parser.core.C-xrHxI2.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-W2GHVCYJ.4KqwC0u7.js.map
