import{G as a,f as G}from"./mermaid-parser.core.C-xrHxI2.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-YCYPL57B.BUEFkfeI.js.map
