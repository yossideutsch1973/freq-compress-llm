import{U as a,C as n}from"./mermaid.core.BJRmWNW1.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.CjmX1bTq.js.map
