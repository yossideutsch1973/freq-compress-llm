import{v as o}from"./2.BnXZFkJe.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.CLiIXbMg.js.map
