import{b as r}from"./_baseUniq.Dm9zV38B.js";var e=4;function a(o){return r(o,e)}export{a as c};
//# sourceMappingURL=clone.DRvgLk8Z.js.map
